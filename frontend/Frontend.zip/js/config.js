/**
 * Frontend runtime config.
 *
 * Local dev (with npm run dev): leave API_ORIGIN empty — dev-server proxies /api, /uploads, /socket.io.
 * Split deploy (Vercel + Render): either keep empty and use vercel.json rewrites, OR set API_ORIGIN to your Render URL.
 */
(function () {
  // In local dev, we rely on the dev-server proxy (leave API_ORIGIN empty).
  // In production on cPanel (caledordmc.co.uk), we must point to the Render backend.
  const PROD_API_ORIGIN = "https://caledor-tour.onrender.com";
  const host = String(window.location?.hostname || "").toLowerCase();
  const isProdHost = host === "caledordmc.co.uk" || host === "www.caledordmc.co.uk";
  const API_ORIGIN = isProdHost ? PROD_API_ORIGIN : "";

  function trimOrigin(origin) {
    return String(origin || "").replace(/\/+$/, "");
  }

  function maybeMediaUrl(url) {
    if (!url) return "";
    const value = String(url).trim();
    if (/^https?:\/\//i.test(value)) return value;
    const path = value.startsWith("/") ? value : `/${value}`;
    const origin = trimOrigin(API_ORIGIN);
    return origin ? `${origin}${path}` : path;
  }

  window.CALEDOR_CONFIG = {
    API_ORIGIN,

    get apiBase() {
      const origin = trimOrigin(API_ORIGIN);
      return origin ? `${origin}/api` : "/api";
    },

    get socketOrigin() {
      const origin = trimOrigin(API_ORIGIN);
      return origin || undefined;
    },

    connectSocket() {
      if (typeof io === "undefined") return null;
      const origin = this.socketOrigin;
      return origin ? io(origin, { path: "/socket.io" }) : io();
    },

    mediaUrl(url) {
      return maybeMediaUrl(url);
    },

    uploadUrl() {
      return `${this.apiBase}/upload`;
    },

    /**
     * Loads socket.io client script from the correct origin.
     * - Local: /socket.io/socket.io.js (dev-server proxy)
     * - Production: https://caledor-tour.onrender.com/socket.io/socket.io.js
     */
    ensureSocketIoClient() {
      if (typeof window.io !== "undefined") return Promise.resolve(window.io);
      if (window.__calediorSocketIoPromise) return window.__calediorSocketIoPromise;

      const socketSrc = this.socketOrigin
        ? `${this.socketOrigin}/socket.io/socket.io.js`
        : "/socket.io/socket.io.js";

      window.__calediorSocketIoPromise = new Promise((resolve, reject) => {
        const existing = document.querySelector('script[data-socket-io="caleriodmc"]');
        if (existing) {
          existing.addEventListener("load", () => resolve(window.io));
          existing.addEventListener("error", reject);
          return;
        }

        const s = document.createElement("script");
        s.async = true;
        s.defer = true;
        s.dataset.socketIo = "caleriodmc";
        s.src = socketSrc;
        s.onload = () => resolve(window.io);
        s.onerror = () => reject(new Error(`Failed to load socket.io client: ${socketSrc}`));
        document.head.appendChild(s);
      });

      return window.__calediorSocketIoPromise;
    },

    /**
     * Production cPanel serves static files only; all media is hosted on Render.
     * This rewrites any hardcoded /uploads/... references in HTML/CMS output
     * so images and background-images load from the correct origin.
     */
    rewriteMediaUrls(root = document) {
      if (!root) return;

      const rewriteUrl = (raw) => {
        if (!raw) return raw;
        const value = String(raw).trim();
        if (!value) return raw;
        if (value.startsWith("/uploads/") || value.startsWith("uploads/")) return maybeMediaUrl(value);
        return raw;
      };

      const rewriteOne = (el) => {
        if (!el || !el.getAttribute) return;

        // <img src="/uploads/...">
        if (el.tagName === "IMG") {
          const src = el.getAttribute("src");
          if (src && (src.startsWith("/uploads/") || src.startsWith("uploads/"))) {
            el.src = rewriteUrl(src);
          }
          return;
        }

        // inline background-image: style="background-image: url('/uploads/...')"
        if (el.hasAttribute && el.hasAttribute("style")) {
          const style = el.getAttribute("style");
          if (style && style.includes("/uploads/")) {
            const next = style.replace(/url\((['"]?)(\/uploads\/[^'")]+)\1\)/g, (_m, q, uploadsPath) => {
              const fixed = maybeMediaUrl(uploadsPath);
              return `url(${q}${fixed}${q})`;
            });
            if (next && next !== style) el.setAttribute("style", next);
          }
        }
      };

      root.querySelectorAll("img").forEach((img) => {
        rewriteOne(img);
      });

      // Handle inline background-image: style="background-image: url('/uploads/...')"
      root.querySelectorAll("[style]").forEach((el) => {
        rewriteOne(el);
      });

      // Ensure dynamically injected content (admin/blog/package cards) also gets fixed.
      // MutationObserver is lightweight because we only touch /uploads references.
      if (root === document && !window.__calediorMediaObserver) {
        window.__calediorMediaObserver = new MutationObserver((mutations) => {
          try {
            for (const m of mutations) {
              if (m.type === "childList") {
                m.addedNodes.forEach((n) => {
                  if (!(n instanceof Element)) return;
                  // rewrite any descendant images/styles
                  n.querySelectorAll?.("img").forEach((img) => rewriteOne(img));
                  n.querySelectorAll?.("[style]").forEach((el) => rewriteOne(el));
                  rewriteOne(n);
                });
              }
              if (m.type === "attributes") {
                const el = m.target instanceof Element ? m.target : null;
                if (el) {
                  const name = m.attributeName;
                  if (name === "src" && el.tagName === "IMG") rewriteOne(el);
                  if (name === "style") rewriteOne(el);
                }
              }
            }
          } catch {
            // ignore rewrite failures; page remains usable
          }
        });
        window.__calediorMediaObserver.observe(document.documentElement, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["src", "style"],
        });
      }
    },
  };

  const runRewrite = () => {
    try {
      window.CALEDOR_CONFIG?.rewriteMediaUrls?.(document);
    } catch {
      // keep page functional even if rewrite fails
    }
  };

  // Run immediately if possible so hardcoded HTML images start loading from the correct origin.
  runRewrite();

  // Also run once after DOM is fully parsed (covers edge cases where nodes are created late).
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", runRewrite, { once: true });
  }
})();
